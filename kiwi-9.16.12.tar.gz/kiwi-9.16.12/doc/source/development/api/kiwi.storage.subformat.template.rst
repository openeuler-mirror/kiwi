kiwi.storage.subformat.template Package
=======================================

Submodules
----------

`kiwi.storage.subformat.template.vmware_settings` Module
--------------------------------------------------------

.. automodule:: kiwi.storage.subformat.template.vmware_settings
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: kiwi.storage.subformat.template
    :members:
    :undoc-members:
    :show-inheritance:
