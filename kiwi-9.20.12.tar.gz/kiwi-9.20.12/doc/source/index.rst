.. kiwi documentation master file

{kiwi} Documentation
=====================

.. note:: {kiwi} vs. {kiwi-legacy}

   This documentation covers {kiwi-product} |version|- the command line
   utility to build Linux system appliances. {kiwi} is stable and all
   new features, bugfixes, and improvements will be developed here.
   Versions older or equal to v7.x.x are out of maintenance and do
   not get any updates or bugfixes. If you still need this version,
   refer to the documentation for
   `{kiwi-legacy} <https://doc.opensuse.org/projects/kiwi/doc>`__

.. toctree::
   :maxdepth: 1

   quickstart
   installation
   self_contained
   overview
   working_with_kiwi
   working_with_images
   building
   commands
   development
   schema
   api

.. sidebar:: Links

   * `GitHub Sources <https://github.com/OSInside/kiwi>`__
   * `GitHub Releases <https://github.com/OSInside/kiwi/releases>`__
   * `RPM Packages <http://download.opensuse.org/repositories/Virtualization:/Appliances:/Builder>`__
   * `Build Tests SUSE(x86) <https://build.opensuse.org/project/show/Virtualization:Appliances:Images:Testing_x86:suse>`__
   * `Build Tests SUSE(arm) <https://build.opensuse.org/project/show/Virtualization:Appliances:Images:Testing_arm:suse>`__
   * `Build Tests SUSE(s390) <https://build.opensuse.org/project/show/Virtualization:Appliances:Images:Testing_s390:suse>`__
   * `Build Tests SUSE(ppc64le) <https://build.opensuse.org/project/show/Virtualization:Appliances:Images:Testing_ppc:suse>`__

   * `Build Tests Fedora(x86) <https://build.opensuse.org/project/show/Virtualization:Appliances:Images:Testing_x86:fedora>`__
   * `Build Tests Fedora(arm) <https://build.opensuse.org/project/show/Virtualization:Appliances:Images:Testing_arm:fedora>`__
   * `Build Tests Fedora(ppc64le) <https://build.opensuse.org/project/show/Virtualization:Appliances:Images:Testing_ppc:fedora>`__

   * `Build Tests CentOS(x86) <https://build.opensuse.org/project/show/Virtualization:Appliances:Images:Testing_x86:centos>`__

   * `Build Tests Ubuntu(x86) <https://build.opensuse.org/project/show/Virtualization:Appliances:Images:Testing_x86:ubuntu>`__

The Appliance Concept
---------------------

An appliance is a ready to use image of an operating system including
a pre-configured application for a specific use case. The appliance is
provided as an image file and needs to be deployed to, or activated in
the target system or service.

{kiwi} can create appliances in various forms: beside classical installation
ISOs and images for virtual machines it can also build images that boot via
PXE or Vagrant boxes.

In {kiwi}, the appliance is specified via a collection of human readable files
in a directory, also called the `image description`. At least one XML file
:file:`config.xml` or :file:`.kiwi` is required. In addition there may as
well be other files like scripts or configuration data.

Use Cases
---------

Not convinced yet? You can find a selection of the possible uses cases
below:

* You are a system administrator and wish to create a customized installer
  for your network that includes additional software and your organizations
  certificates? {kiwi} allows you to select which packages will be included
  in the final image. On top of that you can add files to arbitrary
  locations in the filesystem, for example to include SSL or SSH keys. You
  can also tell {kiwi} to create an image that can be booted via PXE, so that
  you don't even have to leave your desk to reinstall a system.

* You want to create a custom spin of your favorite Linux distribution with
  additional repositories and packages that are not present by default?
  With {kiwi} you can configure the repositories of your final image via the
  image description and tweak the list of packages that are going to be
  installed to match your target audience.

* The Raspberry Pi that is coordinating your home's Internet of Thing (IoT)
  devices got very popular among your friends and every single one of them
  wants a copy of that? {kiwi} will build you ready to deploy images for your
  Raspberry Pi, tweaked to your needs.

Contact
-------

* `Mailing list <https://groups.google.com/forum/#!forum/kiwi-images>`__

  The `kiwi-images` group is an open group and anyone can
  `subscribe <mailto:kiwi-images+subscribe@googlegroups.com>`__,
  even if you do not have a Google account.

* `Matrix <https://matrix.org>`__

  An open network for secure, decentralized communication. Please find the
  ``#kiwi`` room via `Riot <https://riot.im/app/>`__ on the web or by using
  the supported `clients <https://matrix.org/docs/projects/clients-matrix>`__.
