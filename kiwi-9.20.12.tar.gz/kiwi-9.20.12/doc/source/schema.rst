.. _schema-docs:

Image Description XML Schema
============================

.. raw:: html
    :file: schema/schema.html
